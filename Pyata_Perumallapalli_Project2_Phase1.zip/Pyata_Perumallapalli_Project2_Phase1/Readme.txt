Pyata Keerthana 1002029148
Aarona Preethee Perumallapalli 1002029616

1. Loggined into omega by connecting UTA VPN and omega credentials.
2. Now to connect into oracle I used sqlplus command.
3. To login into oracle I used my oracle userid and password.
4. In oracle we have kxp9148 databse where we need to use it as the database for the project.
5. Now I have opened workbench and connected the workbench to the 
		host: acadmysqldb001p.uta.edu  
		username: kxp9148
		Stored Connection is kxp9148
6. After connecting I used kxp9148 database and stated to create tables.
7. Creating tables spool file has been attached in the zipe file stating create_table.txt
8. And a deatiled description of the tables has been given in the report.