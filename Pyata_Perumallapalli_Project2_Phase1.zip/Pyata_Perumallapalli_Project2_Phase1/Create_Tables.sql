"Pyata Keerthana 1002029148
Aarona Preethee Perumallapalli 1002029616"

use kxp9148;

CREATE TABLE books (
    book_id INTEGER,
    isbn INTEGER PRIMARY KEY,
    title VARCHAR(30),
    author VARCHAR(30),
    publisher VARCHAR(30),
    job_title VARCHAR(30)
    );
    
   CREATE TABLE catalog (
    catalog_id   INTEGER NOT NULL,
    isbn         INTEGER NOT NULL,
    title        VARCHAR(30),
    author       VARCHAR(30),
    subject_area VARCHAR(30)
);
ALTER TABLE catalog ADD CONSTRAINT catalog_pk PRIMARY KEY ( catalog_id );

CREATE TABLE members (
    member_id          INTEGER NOT NULL,
    isbn 			   INTEGER NOT NULL,
    first_name         VARCHAR(20) NOT NULL,
    last_name          VARCHAR(20) NOT NULL,
    address            VARCHAR(20) NOT NULL,
    contact            INTEGER NOT NULL,
    foreign key (isbn) references books(isbn)
);
 ALTER TABLE members ADD CONSTRAINT members_pk PRIMARY KEY ( member_id );
 ALTER TABLE members ADD CONSTRAINT members__un UNIQUE ( contact );
 
 CREATE TABLE staff (
    staff_id   INTEGER NOT NULL,
    first_name VARCHAR(20) NOT NULL,
    last_name  VARCHAR(20) NOT NULL,
    job_title  VARCHAR(20) NOT NULL,
    address    VARCHAR(20) NOT NULL,
    contact    INTEGER NOT NULL,
    hire_date  DATE NOT NULL
);
ALTER TABLE staff ADD CONSTRAINT staff_pk PRIMARY KEY ( staff_id );
ALTER TABLE staff ADD CONSTRAINT staff__un UNIQUE ( contact );

CREATE TABLE book_copies (
    isbn        INTEGER NOT NULL,
    book_id     INTEGER NOT NULL,
    member_id   INTEGER NOT NULL,
    borrow_date DATE NOT NULL,
    return_date DATE NOT NULL,
    cost        DECIMAL(10,2),
    status      CHAR(3) NOT NULL,
    staff_id    INTEGER NOT NULL
);
ALTER TABLE book_copies ADD CONSTRAINT book_copies_books_FK FOREIGN KEY ( isbn ) REFERENCES books ( isbn ) ON DELETE CASCADE;
ALTER TABLE book_copies ADD CONSTRAINT book_copies_members_FK FOREIGN KEY ( member_id ) REFERENCES members ( member_id ) ON DELETE CASCADE;
ALTER TABLE book_copies ADD CONSTRAINT book_copies_staff_FK FOREIGN KEY ( staff_id ) REFERENCES staff ( staff_id ) ON DELETE CASCADE;
ALTER TABLE books ADD CONSTRAINT books_catalog_fk FOREIGN KEY ( isbn ) REFERENCES catalog ( catalog_id ) ON DELETE CASCADE;


